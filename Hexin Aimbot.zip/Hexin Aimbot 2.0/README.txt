INSTALLATION

For those of you who have not used my program previously it used to only be usable through manually installing it which most people hate doing so I gave in and just made an injector for the sake of conveinence,
basically all that means is that you run the exe and it will install itself into the game without you having to go in the files and do it on your own, as of July
2020 the aimbot is still alive and well. Not to mention completely undetectable by anticheat but keep in mind toggling the aimbot at certain times can make
you a dead giveaway to anyone who is looking for it.

!!!BEFORE CONTACTING PLEASE RUN THE INJECTOR IN ADMINISTRATOR MODE, THIS FIXES 90% OF PROBLEMS I HAVE BEEN COMPLAINED TO ABOUT!!!!

BASIC CONTROLLS

To toggle the aimbot it will be whatever button you have the console set to (~ key by default) and then RMB

To switch the camera snapping position use the numberpad on the far right side of the keyboard, 0 switches right to the head hitbox and the 1 key will lock you on to the torso which is 
what it will be set to upon first installing.

I know and understand that this setup isn't the most user friendly, but as long as you can remember the keys you will be fine, maybe practice a little
in singleplayer to get a feel for it.


I AM NOT RESPONSIBLE FOR ANY NEGATIVE AFFECTS OF YOU USING MY AIMBOT! NOT BEING CAREFULL IS YOUR FAULT!



Hexin205